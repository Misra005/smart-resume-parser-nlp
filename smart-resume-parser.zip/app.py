import streamlit as st
import pandas as pd
import json
from parser import *

st.set_page_config(page_title="Smart Resume Parser", page_icon="📄")
st.title("📄 Smart Resume Parser")

uploaded_file = st.file_uploader("Upload Resume", type=["pdf","docx"])

if uploaded_file:
    if uploaded_file.name.endswith(".pdf"):
        text = extract_text_from_pdf(uploaded_file)
    else:
        text = extract_text_from_docx(uploaded_file)

    data = extract_resume_data(text)

    st.subheader("Extracted Information")
    st.write(data)

    st.download_button(
        "Download JSON",
        json.dumps(data, indent=4),
        file_name="resume_data.json"
    )

    df = pd.DataFrame([data])
    st.download_button(
        "Download CSV",
        df.to_csv(index=False),
        file_name="resume_data.csv"
    )
