import fitz
import docx
import re
import pandas as pd
import spacy

nlp = spacy.load("en_core_web_sm")

def extract_text_from_pdf(pdf_file):
    text = ""
    pdf = fitz.open(stream=pdf_file.read(), filetype="pdf")
    for page in pdf:
        text += page.get_text()
    return text

def extract_text_from_docx(docx_file):
    document = docx.Document(docx_file)
    text = ""
    for para in document.paragraphs:
        text += para.text + "\n"
    return text

def extract_email(text):
    emails = re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', text)
    return emails[0] if emails else "Not Found"

def extract_phone(text):
    phones = re.findall(r'(\+?\d[\d\s\-]{8,15})', text)
    return phones[0] if phones else "Not Found"

def extract_name(text):
    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            return ent.text
    return "Not Found"

def extract_skills(text):
    skills_df = pd.read_csv("skills.csv", header=None)
    skills_list = skills_df[0].tolist()
    return list({skill for skill in skills_list if skill.lower() in text.lower()})

def extract_education(text):
    keywords = ["B.Tech","B.E","M.Tech","MCA","BCA","MBA","Diploma","Bachelor","Master"]
    return [k for k in keywords if k.lower() in text.lower()]

def extract_resume_data(text):
    return {
        "Name": extract_name(text),
        "Email": extract_email(text),
        "Phone": extract_phone(text),
        "Skills": extract_skills(text),
        "Education": extract_education(text)
    }
